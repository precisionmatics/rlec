"""
RLEC command-line interface.

Usage:
    rlec --version
    rlec info
    rlec transform RNA.pdb LIGAND.sdf [options]
"""

import argparse
import sys


def cmd_info(args):
    from rlec import __version__
    from rlec import RLECFingerprint
    fp = RLECFingerprint()
    print(f"rlec {__version__}")
    print(f"Default: {fp!r}")
    print("feat_set options:")
    print("  0 — basic ECFP (atomic_num, charge, degree, aromaticity, ring)")
    print("  1 — + nucleotide type A/U/G/C/T  [best, LOOCV r=0.710]")
    print("  2 — + PBS group (Phosphate/Sugar/Base)")
    print("  3 — + nucleotide type + PBS group")


def cmd_transform(args):
    import numpy as np
    from rlec import RLECFingerprint

    fp = RLECFingerprint(
        rna_depth=args.rna_depth,
        ligand_depth=args.lig_depth,
        fp_size=args.fp_size,
        feat_set=args.feat_set,
        cutoff=args.cutoff,
    )

    vec = fp.transform(args.rna, args.ligand)
    nonzero = int((vec > 0).sum())

    if args.output:
        np.save(args.output, vec)
        print(f"Saved: {args.output}  shape={vec.shape}  nonzero={nonzero}")
    else:
        # Print as space-separated floats (or summary if large)
        if args.fp_size <= 512:
            print(" ".join(str(int(x)) for x in vec))
        else:
            print(f"shape={vec.shape}  nonzero={nonzero}  sum={vec.sum():.0f}")
            print("(Use --output FILE.npy to save the full vector)")


def main():
    parser = argparse.ArgumentParser(
        prog="rlec",
        description="RNA-Ligand Extended Connectivity Fingerprint",
    )
    parser.add_argument("--version", action="version",
                        version=f"%(prog)s {__import__('rlec').__version__}")

    sub = parser.add_subparsers(dest="command")

    # rlec info
    sub.add_parser("info", help="Show version and default parameters")

    # rlec transform
    t = sub.add_parser("transform", help="Compute RLEC fingerprint for one complex")
    t.add_argument("rna",    help="RNA PDB file path")
    t.add_argument("ligand", help="Ligand SDF file path")
    t.add_argument("--rna-depth",  type=int,   default=6,    dest="rna_depth")
    t.add_argument("--lig-depth",  type=int,   default=3,    dest="lig_depth")
    t.add_argument("--fp-size",    type=int,   default=4096, dest="fp_size")
    t.add_argument("--feat-set",   type=int,   default=1,    dest="feat_set",
                   choices=[0, 1, 2, 3])
    t.add_argument("--cutoff",     type=float, default=6.0)
    t.add_argument("--output",     default=None, metavar="FILE.npy",
                   help="Save fingerprint vector as .npy (optional)")

    args = parser.parse_args()

    if args.command == "info":
        cmd_info(args)
    elif args.command == "transform":
        cmd_transform(args)
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
