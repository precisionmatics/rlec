"""
RLEC — RNA-Ligand Extended Connectivity Fingerprint

Adapts the PLEC fingerprint concept (Wójcikowski et al., Bioinformatics 2019)
to RNA-ligand systems for binding affinity prediction.

Usage:
    from rlec import RLECFingerprint
    fp = RLECFingerprint(rna_depth=5, ligand_depth=1, fp_size=65536)
    bits = fp.transform(rna_mol, ligand_mol)
"""

__version__ = "0.1.2"
__author__ = "Stalin A"
__email__ = "stalin.bioinfo@gmail.com"

from rlec.fingerprint import RLECFingerprint

__all__ = ["RLECFingerprint"]
